let EmojiArray = [
    { id: 1, Emoji: "☃️", EmojiName: "Emoji", AboutEmoji: "this is smiling", TimeStamp:"already" },
    { id: 2, Emoji: "🚙", EmojiName: "Emoji1", AboutEmoji: "these are smileys" },
    { id: 3, Emoji: "💙", EmojiName: "Emoji2", AboutEmoji: "these are smileys" },
    { id: 4, Emoji: "🤦‍♂️", EmojiName: "Emoji3", AboutEmoji: "these are smileys" },
    { id: 5, Emoji: "🐳", EmojiName: "Emoji4", AboutEmoji: "these are smileys" },

]

// delete
let GetHome = (req, res) => {
    console.log(req.query.deleteEmoji)


    let whatToDelte = req.query.deleteEmoji

    if (req.query.deleteEmoji) {
        console.log("it's deleted")

        EmojiArray = EmojiArray.filter((element, index) => {
            return element.id != whatToDelte
        })

        res.status(201).redirect("/")


    } else {
        console.log("nothing to delete")
        res.status(200).render("index.ejs", { EmojiArray })
    }
}

// add
let PostHome = (req, res) => {

    console.log(req.body);

    let MyObj = {
        Emoji:req.body.emoji,
        EmojiName:req.body.emojiName,
        AboutEmoji:req.body.aboutEmoji
    }

    let newEmojiObject =MyObj

    let date = new Date()

    let whatTime = `${date.toLocaleTimeString()} | ${date.toLocaleDateString()} `

    console.log(whatTime)

    newEmojiObject = { ...newEmojiObject, id: EmojiArray[EmojiArray.length - 1].id + 1 , timeStamp: whatTime }

    EmojiArray.unshift(newEmojiObject)

    console.log(EmojiArray)

    res.status(201).redirect("/")
}

export { GetHome, PostHome }



    // this will add emoji at end (push)
    // EmojiArray.push(newEmojiObject)

    // this will add at start (unshift)
    // EmojiArray.unshift(newEmojiObject)

  



   